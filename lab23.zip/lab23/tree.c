#include <stdio.h>
#include "tree.h"

// создание ноды
tnode *tree_create(Item a)
{
    tnode *q = (tnode*)malloc(sizeof(tnode));
    q->data = a;
    q->childs = NULL;
    q->next = NULL;
    return q;
}

// удаление ноды
void tree_destroy(tnode* a)
{
        if(a==NULL)
                return;
        tree_destroy(a->childs);
        tree_destroy(a->next);
        free(a);
}

// добавление ребенка к ноде
void tree_add(tnode* a,Item b)
{
        if(a->childs)
        {
                tnode *new1=tree_create(b);
                new1->next=a->childs;
                a->childs=new1;
        }
        else
                a->childs=tree_create(b);
}

// поиск по значению в дереве
tnode *tree_find(tnode* a,Item b)
{
        if(a==NULL)
                return NULL;
        if(a->data==b)
                return a;
        tnode *chld1=tree_find(a->childs,b);
        if(chld1)
                return chld1;
        tnode *nxt1=tree_find(a->next,b);
        if(nxt1)
                return nxt1;
        return NULL;
}

// поиск родителя ноды
tnode *tree_parent_find(tnode* a,tnode* b)
{
        if(a==NULL)
                return NULL;
        if(a->childs==b || a->next==b)
                return a;
        tnode *chld1=tree_parent_find(a->childs,b);
        if(chld1!=NULL)
                return chld1;
        tnode *nxt1=tree_parent_find(a->next,b);        
        if(nxt1!=NULL)
                return nxt1;
        return NULL;
}

// удаление ноды из дерева
void tree_delete(tnode* a,tnode* b)
{
        tnode *par1=tree_parent_find(a,b);
        if(par1->childs==b)
                par1->childs=b->next;
        else
                par1->next=b->next;
        tree_destroy(b->childs);
        free(b);
}

// вспомогательная рекурсивная функция распечатки
void tree_print_int(tnode* a,int b,char *c[])
{
        if(a==NULL)
                return;
        for(int i=0;i<b;i++)
                printf("\t");
        printf("%s\n",c[a->data]);
        tree_print_int(a->childs,b+1,c);
        tree_print_int(a->next,b,c);
}

// распечатка дерева
void tree_print(tnode* a,char *b[])
{
        tree_print_int(a,0,b);
}

// высота дерева
void tree_height(tnode* a,int b,int *c)
{
        if(a==NULL)
                return;
        if(b>*c)
                *c=b;
        tree_height(a->childs,b+1,c);
        tree_height(a->next,b,c);
}

// вспомогательная рекурсивная функция ширины дерева
void tree_width_int(tnode* a,int b,int *c)
{
        if(a==NULL)
                return;
        c[b]++;
        tree_width_int(a->childs,b+1,c);
        tree_width_int(a->next,b,c);
}

// ширина дерева
int tree_width(tnode* a)
{
        int maxh1=0;
        tree_height(a,1,&maxh1);
        int w1[maxh1];
        for(int i=0;i<maxh1;i++)
                w1[i]=0;
        tree_width_int(a,0,w1);
        int maxi1=0;
        for(int i=1;i<maxh1;i++)
                if(w1[i]>w1[maxi1])
                        maxi1=i;
        return w1[maxi1];
}