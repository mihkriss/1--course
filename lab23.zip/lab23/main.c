#include <stdio.h>
#include "tree.h"

enum mendel1 {
m_root,
m_Argentum,
m_Argon,
m_Arsenicum,
m_Astatum,
m_Aurum,
m_Barium,
m_Berkelium,
m_Beryllium,
m_Bismuthum
};

char *mendel2[]={
"root",
"Argentum",
"Argon",
"Arsenicum",
"Astatum",
"Aurum",
"Barium",
"Berkelium",
"Beryllium",
"Bismuthum"
};

enum mendel1 fromstring1(char a[20])
{
        for(int i=0;i<sizeof(mendel2)/sizeof(char*);i++)
                if(strcmp(a,mendel2[i])==0)
                        return i;
        return -1;
}

int main(int argc,char *argv[])
{
    printf("команды:\n"
    "i <parent> <elem> - вставка элемента\n"
    "p - распечатать все дерево\n"
    "d <elem> - удалить элемент (и поддерево)\n"
    "w - распечатать ширину дерева\n"
    "q - выход и освобождение ресурсов\n");
    tnode *mt1=tree_create(0);
    char run1=1;
    while(run1)
    {
        printf("> ");
        char in1;
        read1:
        scanf("%c",&in1);
        switch(in1)
        {
            case 'i':
            {
                char in2[20];
                char in3[20];
                scanf("%s %s",in2,in3);
                tree_add(tree_find(mt1,fromstring1(in2)),fromstring1(in3));
                break;
            }
            case 'p':
            {
                tree_print(mt1,mendel2);
                break;
            }
            case 'd':
            {
                char in2[20];
                scanf("%s",in2);
                tree_delete(mt1,tree_find(mt1,fromstring1(in2)));
                break;
            }
            case 'w':
            {
                printf("ширина дерева: %d\n",tree_width(mt1));
                break;
            }
            case 'q':
            {
                run1=0;
                break;
            }
            case '\n':
            {
                goto read1;
            }
            default:
            {
                printf("неверная команда\n>");
                goto read1;
            }
        }
    }
    tree_destroy(mt1);
    return 0;
}