#ifndef TREE_H
#define TREE_H

#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

typedef int Item;

typedef struct tnode tnode;

struct tnode {
    Item data;
    tnode *childs;
    tnode *next;
};

tnode *tree_create(Item);
void tree_destroy(tnode*);
void tree_add(tnode*,Item);
tnode *tree_find(tnode*,Item);
void tree_delete(tnode*,tnode*);
void tree_print(tnode*,char*[]);
int tree_width(tnode*);

#endif